plugins {
    id("com.android.application")
}

android {
    namespace = "com.vrides.customer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vrides.customer"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
