package com.vrides.customer;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;

public class MainActivity extends Activity {
    private LinearLayout root;
    private EditText nameInput, phoneInput, otpInput;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showRegistration();
    }

    private void setup(String subtitle) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setGravity(Gravity.CENTER_VERTICAL);
        root.setBackgroundColor(Color.rgb(247, 249, 252));

        TextView brand = new TextView(this);
        brand.setText("V RIDES");
        brand.setTextSize(30);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setTextColor(Color.rgb(20, 70, 160));
        root.addView(brand);

        TextView sub = new TextView(this);
        sub.setText(subtitle);
        sub.setTextSize(16);
        sub.setTextColor(Color.DKGRAY);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.bottomMargin = dp(22);
        root.addView(sub, sp);
        setContentView(root);
    }

    private void showRegistration() {
        setup("Customer registration");
        nameInput = field("Full name", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        phoneInput = field("10-digit mobile number", InputType.TYPE_CLASS_PHONE);
        Button next = button("Continue");
        root.addView(next);
        next.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String phone = phoneInput.getText().toString().trim();
            if (name.isEmpty()) { nameInput.setError("Enter your name"); return; }
            if (!phone.matches("[0-9]{10}")) { phoneInput.setError("Enter a 10-digit mobile number"); return; }
            showOtp(name, phone);
        });
        addNote("Demo only: this screen does not send an SMS or save an account.");
    }

    private void showOtp(String name, String phone) {
        setup("Verify mobile number");
        TextView details = new TextView(this);
        details.setText("Customer: " + name + "\\nMobile: " + phone);
        details.setTextSize(16);
        details.setTextColor(Color.DKGRAY);
        root.addView(details);
        otpInput = field("Enter demo OTP", InputType.TYPE_CLASS_NUMBER);
        Button verify = button("Verify and finish");
        root.addView(verify);
        verify.setOnClickListener(v -> {
            if ("123456".equals(otpInput.getText().toString().trim())) {
                setup("Registration demo complete");
                addNote("Welcome, " + name + "!\\n\\nYour customer registration flow passed the local demo test. No account was created on a server.");
                Button restart = button("Back to registration");
                root.addView(restart);
                restart.setOnClickListener(x -> showRegistration());
            } else {
                otpInput.setError("For testing, enter 123456");
            }
        });
        addNote("Test OTP: 123456. This is not real phone verification.");
    }

    private EditText field(String hint, int type) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setHint(hint);
        e.setInputType(type);
        e.setTextSize(16);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(12);
        root.addView(e, p);
        return e;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(8);
        root.addView(b, p);
        return b;
    }

    private void addNote(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(13);
        t.setTextColor(Color.GRAY);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(18);
        root.addView(t, p);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
