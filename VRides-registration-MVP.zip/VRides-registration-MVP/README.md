# V Rides — Customer and Driver Registration Starter

This is a starter Android Studio project with two separate apps:
- Customer app: name + phone registration, followed by a demo OTP screen.
- Driver app: name + phone + driving licence number + vehicle registration number, followed by a pending-review screen.

## Important limitations
- Registration is currently a local demo and does not save accounts to a server.
- The OTP `123456` is a TEST-ONLY demo code, not real SMS verification.
- Driver documents are not uploaded or verified.
- There is no live ride booking, GPS tracking, payments, or production admin panel yet.
- Do not use this demo to collect real sensitive documents or passwords.

## Open on Windows
1. Extract the ZIP to a normal folder, for example `C:\VRides`.
2. Open Android Studio.
3. Choose **Open** and select the extracted `VRides-registration-MVP` folder.
4. Allow Gradle sync to finish. Use JDK 17 if Android Studio asks.
5. If prompted to install Android SDK Platform 35, accept.
6. Choose the `customer` run configuration/module and run it on an emulator or USB-connected Android phone.
7. Then choose the `driver` module and run it.

## Build APKs
After Gradle sync succeeds, open Android Studio's Terminal at the project root and run:
`gradlew.bat :customer:assembleDebug :driver:assembleDebug`

Expected outputs:
- `customer\build\outputs\apk\debug\customer-debug.apk`
- `driver\build\outputs\apk\debug\driver-debug.apk`

If Windows says `gradlew.bat` is missing, use Android Studio's **Build > Build APK(s)** after selecting each app module, or generate a Gradle wrapper from Android Studio/Gradle installation.

## Next milestones
1. Add a real backend and database.
2. Add production phone OTP with a trusted authentication provider.
3. Add secure driver document upload and admin approval.
4. Add ride requests, driver availability, GPS, notifications, and payments.
