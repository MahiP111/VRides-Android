package com.vrides.driver;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.text.InputType;

public class MainActivity extends Activity {
    private LinearLayout root;
    private EditText nameInput, phoneInput, licenceInput, vehicleInput;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showRegistration();
    }

    private void setup(String subtitle) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setGravity(Gravity.CENTER_VERTICAL);
        root.setBackgroundColor(Color.rgb(247, 249, 252));

        TextView brand = new TextView(this);
        brand.setText("V RIDES");
        brand.setTextSize(30);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setTextColor(Color.rgb(20, 70, 160));
        root.addView(brand);

        TextView sub = new TextView(this);
        sub.setText(subtitle);
        sub.setTextSize(16);
        sub.setTextColor(Color.DKGRAY);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.bottomMargin = dp(18);
        root.addView(sub, sp);
        setContentView(root);
    }

    private void showRegistration() {
        setup("Driver registration");
        nameInput = field("Full name", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        phoneInput = field("10-digit mobile number", InputType.TYPE_CLASS_PHONE);
        licenceInput = field("Driving licence number", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        vehicleInput = field("Bike registration number", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);

        Button submit = button("Submit for review");
        submit.setOnClickListener(v -> {
            if (nameInput.getText().toString().trim().isEmpty()) { nameInput.setError("Enter your name"); return; }
            if (!phoneInput.getText().toString().trim().matches("[0-9]{10}")) { phoneInput.setError("Enter a 10-digit mobile number"); return; }
            if (licenceInput.getText().toString().trim().isEmpty()) { licenceInput.setError("Enter licence number"); return; }
            if (vehicleInput.getText().toString().trim().isEmpty()) { vehicleInput.setError("Enter bike registration number"); return; }
            showPending(nameInput.getText().toString().trim());
        });
        addNote("Demo only: details remain on this screen and are not uploaded or saved. Do not enter real sensitive data.");
    }

    private void showPending(String name) {
        setup("Driver application");
        addNote("Thanks, " + name + ".\\n\\nYour demo form passed validation. In the real service, an admin must verify your licence, vehicle documents, insurance and eligibility before activation. This demo has not submitted anything to a server.");
        Button restart = button("Back to registration");
        restart.setOnClickListener(v -> showRegistration());
    }

    private EditText field(String hint, int type) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setHint(hint);
        e.setInputType(type);
        e.setTextSize(16);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(8);
        root.addView(e, p);
        return e;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(8);
        root.addView(b, p);
        return b;
    }

    private void addNote(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setTextColor(Color.GRAY);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(16);
        root.addView(t, p);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
