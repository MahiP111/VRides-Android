plugins {
    id("com.android.application")
}

android {
    namespace = "com.vrides.driver"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vrides.driver"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
